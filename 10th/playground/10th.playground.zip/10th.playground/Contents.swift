import Foundation

func sayHello(_ who: String, emotion with: String = "grin") -> Int{
    return 10
    
}
let ret = sayHello("BTS", emotion: "Smile") //함수 정의할 때 파라미터에 _ 넣으면 파라미터 값 호출하지 않아도 됨
//_를 넣지 않았다면
//let ret = sayHello(who: "BTS", with: emotion: "Smile")


let ret2 = sayHello("BlackPink")

//함수타입 - 함수를 객체로 취급 가능하다
// - 함수를 변수에 대입
//함수를 파라미터로 사용하기
// 함수를 반환값으로 사용하기

let fn: (String, String) -> Int = sayHello

//()는 void, 파라미터가 함수인 함수 정의
func doTask(task: (String) -> () ) {
    
}

func argFn(arg: String) -> () {
    
}

doTask(task: argFn)

let argFn2 = { (arg: String) -> () in
}

// 함수를 클로저 표현으로 만들어서 사용
doTask(task: {(arg:String) -> () in
})
doTask(task: argFn2)

doTask() { (arg: String) -> () in
}

// 비어있는 괄호는 생략 가능
doTask{ (arg: String) -> () in
}

doTask{ arg in
    
}
