////미션1, 2
//
//func wouldYouDance(title: String, withSing: (Bool)){
//    if withSing == true{
//        print("\(title)을 노래하면서 춤도 춤")
//    }else {
//        print("\(title)에 맞춰 춤을 춤")
//    }
//}
//
//wouldYouDance(title: "Dynamite", withSing: true)
//
//(int,double) -> int
// ([string]) -> int
// (string, int) -> [string: int]
let fn1 = { (arg1: Int, arg2: Double) -> Int in
    return 10
}

func fn2(arg1: Int, arg2: Double) -> Int {
    return 10
}

fn1(10, 10.0)
fn2(arg1: 20, arg2: 20.0)

let fn3 = { (songs: [String]) -> Int in
    return songs.count
}
let ret3 = fn3(["다이나마이트", "봄날"])

let fn4 = { (arg1: String, arg2: Int) -> [String: Int] in
    return["one":1, "two":2, ]
}

//미션1
//func wouldYouDance(_ song: String, _ withDance: Bool){
//    if withDance == true{
//        print("\(song) 노래에 맞춰 춤을 추겠습니다.")
//    }else{
//        print("\(song) 노래를 부르겠습니다.")
//    }
//        
//}
//wouldYouDance("Dynamic", true)

//미션 2 클로저 표현
//(Int, Double) -> Int
//([String]) -> Int
//(String, Int) -> [String: Int]

//map
let originArray = [1,2,3,4,5]
let mappedArray1 = originArray.map({(item: Int) -> Int in
    return item * 2
})
let mappedArray2 = originArray.map({(item: Int) -> String in
    return ("\(item * 2)")
})

let mapFn = { (item: Int) -> Double in
    return Double(item) / 2
}
let mappedArray3 = originArray.map(mapFn)

//filter
let filterFn = {(item:Int) -> Bool in
    return item % 2 == 0
}
let filtered1 = originArray.filter(filterFn)

let filtered2 = originArray.filter{item in
    return item % 2 != 0
}
