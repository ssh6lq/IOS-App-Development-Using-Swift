//import UIKit
//
//let originArray = [1,4,2,6,7]
//
//originArray.map({(item: Int) -> Int in
//    return item * 2
//})
//
//originArray.map() { (item: Int) -> String in
//    return "\(item * 2)"
//}
//let mappedArray1 = originArray.map( {(itme: Int) -> Int in
//    return item * 2
//})
//
//
//let mappedArray2 = originArray.map() { (item: Int ) -> String in
//    return "\(item * 2)"
//}
//
//let mappedArray3 = originArray.map( mapFn )
//
//let filterFn = { (item)}

// map, filter, reduce
let originArray = [1, 4, 2, 6, 7]

let mappedArray1 = originArray.map( {(item: Int) -> Int in
    return item * 2
})
let mappedArray2 = originArray.map() { (item: Int) -> String in
    return "\(item * 2)"
}

let mapFn = { (item: Int) -> Double in
    return Double(item) / 2
}

let mappedArray3 = originArray.map( mapFn )

let filterFn = { (item: Int) -> Bool in
    return item % 2 == 0
}

let filtered1 = originArray.filter(filterFn)

let filtered2 = originArray.filter { item in
    return item % 2 != 0
}
