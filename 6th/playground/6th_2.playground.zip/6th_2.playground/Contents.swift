struct Market{
    var name: String
    var price: Int
    var sale: Bool
    
    func introduceMenu() {
        print("이 상품은 \(name)이고, 할인이 \(sale ? "적용됩니다." : "적용되지 않습니다.") 가격은 \(price)입니다.")
    }
}

var snack = Market(name: "홈런볼", price: 1200, sale: false)
var food = Market(name: "초밥", price: 13000, sale: true)
var drink = Market(name: "콜라", price: 1000, sale: true)

var products: [Market] = [snack, food, drink]

for product in products{
    product.introduceMenu()
}
