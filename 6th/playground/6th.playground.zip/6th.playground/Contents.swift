import SwiftUI



var scores: Dictionary<String, Int> = ["민수":98, "진희":32, "수아":33]
var heights: Dictionary<String, Double> = ["민수":178.34, "진희":176, "수아":177.3]

//구조체 구조화
//
//struct 구조체이름 {
//    내용
//}

//camel case
//uppercamelcase
//lowercamelcase

//snake case


struct SuperCar{
    
}

struct Student{
    //프로퍼티
    var name: String
    var height: Double
    var phoneNumber: String
    var score: Int
    
    //함수 작성 가능
    
    func makeIntroduction() -> String{
        return "이름은 \(name)이고, 점수는 \(score) 입니다"
    }
}

var number: Int = 10
var firstStudent: Student = Student(name: "민수", height: 178.23, phoneNumber: "231312", score: 78)

print(firstStudent)

var students: [Student] = [
    Student(name: "지아", height: 234.23, phoneNumber: "234234234", score: 34),
    Student(name: "수아", height: 212.23, phoneNumber: "213131", score: 23)]

for student in students{
    print(student)
}


print(firstStudent.name)
print(firstStudent.height)

firstStudent.score = 90

print(firstStudent.score)

print(firstStudent.makeIntroduction())
  
