//1 enemerations

//Int : 64, -
//봄, 여름, 가을, 겨울
//봄에도 봄, spring, Spring 쓰는 표현이 다양함

//enum Season{
//    case spring
//    case summer
//    case autumn
//    case winter
//}

//let season1 = Season.autumn
//let season2 = Season.summer

//enum으로 타입 정의
//이렇게만 쓰자고 정의
//4가지 계절을 정하기위해 enum 사용

enum Season: String {
    case spring = "봄"
    case summer = "여름"
    case autumn = "가을"
    case winter = "겨울"
    
    func hello() {
        
    }
}

let season1 = Season.autumn
print(season1.rawValue)

let season2 = Season.summer
print(season2.rawValue)
season1.hello()

//다른 예시는 뭐가 있을까
//case1

enum Days: String {
    case monday = "월요일"
    case tuesday = "화요일"
    case wednesday = "수요일"
    case thursday = "목요일"
    case friday = "금요일"
    case saturday = "토요일"
    case sunday = "일요일"
}

let today = Days.friday
let yesterday = Days.thursday
print("어제는 \(yesterday.rawValue)이였고, 오늘은 \(today.rawValue)입니다.")

//case2

enum MusicGenre {
    case rock
    case pop
    case jazz
    case classical
    case hipHop
}

let favoriteGenre = MusicGenre.rock
print("제가 좋아하는 음악 장르는 \(favoriteGenre)입니다.")

enum ReportStatus: Int {
    case accepted = 1
    case rejected = 2
}

let status: ReportStatus? = ReportStatus(rawValue: 1) 
//지정된 수가 아닌 다른 수가 들어갈 수 있으니 옵셔널로 지정 --> if 사용

if let unwrappedStatus = ReportStatus(rawValue: 1){
    
}



