import UIKit
import Foundation

//protocol
struct Order : Identifiable {
    //import foundation
    // 첫번째 항목과 두번째 항목이 다르다는 걸로 인식 시켜줘야함 -> id 이용
    var id = UUID() //자동으로 id 생성해줌 (프로토콜)
}

//프로토콜은 일종의 규칙
//team1
protocol Playable {
    func play(hour: Int)
    var playTime: Int { get }
}

//team2
struct Human : Playable {
    var playTime: Int
    
    func play(hour: Int) {
    }
}


protocol Study {
    mutating func study(hour: Int) // 구조체 - 프로퍼티 수정 가능
    var studyTime: Int { get }
}

struct Student : Study{
    let name: String
    var studyTime: Int = 0
    mutating func study(hour: Int) {
        studyTime += hour
    }
}

struct Child: Study{
    mutating func study(hour: Int) {
        studyTime += Int(hour/3)
    }
    var studyTime: Int = 0
}

var student = Student(name: "aa")
student.study(hour: 1)
student.study(hour: 2)
print(student.studyTime)

struct Library {
    func enter(anyOne: Study) {
        
    }
}

var library = Library()

//struct Student: Study {
//    //mutating은 study를 통해서 studytime을 수정하기 위해서
//    mutating func study(hour: Int) {
//        studyTime += hour
//        print("저는 오늘\(hour)시간 공부했으며, 총 공부 시간은 \(studyTime)시간 입니다.")
//    }
//    var studyTime: Int
//}
