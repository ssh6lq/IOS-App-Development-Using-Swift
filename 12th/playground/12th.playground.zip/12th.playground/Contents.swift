import UIKit

struct MovieStruct {
    var title: String
    var year: Int
}

let movieObj1 = MovieStruct(title: "title", year: 2000)

class MovieClass {
    var title: String
    var year: Int
    
    //초기화하는 코드를 작성해야 하는 프로퍼티
    var property1 = 1
    var property2 : Int?
    var property3 : Int!
    
    
    //초기화가 반드시 필요한 프로퍼티
    init() {
        title = "title"
        year = 2000
    }
    init(title: String, year: Int) {
        self.title = title
        self.year = year
    }
}

let movieObj2 = MovieClass()
let movieObj3 = MovieClass(title: "title2", year: 2020)

// class와 구조체의 다른점 : 상속
//새로운 타입 생성 -> 부모 클래스 프로퍼티, 메소드

//부모 클래스
class SuperClass {
    var value = 0
    func sayHello(){
        print("hello")
    }
}

//자식 클래스
class ChildClass: SuperClass{
    var value2 = 10
}

let child1 = ChildClass()
print(child1.value)
child1.sayHello()
child1.value2 = 100

class Sound {
    var volume = 0
    var wiresss = false
}

class Speaker: Sound{
    func batterty(){
        
    }
}
class Amplifier: Sound{
    
}
class Earphones: Sound{
    
}

class Animal {
    var energy = 100
    func eat(){
        
    }
    func move(){
        
    }
}

class Bird: Animal{
    func fly() {
        
    }
    
}
class Dog: Animal{
    func bike(){
        
    }
}

// 구조체
struct MyStruct {
    var value = 0
}

//클래스
class MyClass {
    var value = 0
}
//구조체는 변경시 할당한 구조체 변경 안됨
var structObj1 = MyStruct()
var structObj2 = structObj1

print(structObj1.value, structObj2.value)

structObj1.value = 10

print(structObj1.value, structObj2.value)

//클래스는 값을 변경하면 상속 값도 똑같이 바뀜
var classObj1 = MyClass()
var classObj2 = classObj1

print(classObj1.value, classObj2.value)

classObj1.value = 10

print(classObj1.value, classObj2.value)
